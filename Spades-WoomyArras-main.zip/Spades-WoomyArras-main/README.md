# Spade's Woomy Arras  
## A restored offline version of woomy arras
MORE UPDATED VERSION, THE WOOMYARCHIVES: https://github.com/DrakoHyena/WoomyArchives

## How to play
Download the ZIP file (the green CODE button, then Download ZIP)  
Open index.html  
Or go to https://woomy-arras.runbsd.io

## Alternate URLs
- https://woomy-arras.runbsd.io
- https://spades-woomy-arras.vercel.app
- https://woomy-arras.vercel.app
- https://woomy-modded.vercel.app

## What is this
This is a full backup/copy of Drako Hyena's woomy-arras.io copy.  
This has been modified by me (Spade1345/The Highwayman/Surge EMPs) to have many tanks readded.  
- Bots don't have an [AI] badge anymore

# Non-working Features
- Discord Bot and other remote services
- Old Menu (still exists; changing between the menus was handled by Oblivion with the site host)

# Removed Features
- IP/VPN Banning
- Tab Limit
- Bans
- IP Limit
